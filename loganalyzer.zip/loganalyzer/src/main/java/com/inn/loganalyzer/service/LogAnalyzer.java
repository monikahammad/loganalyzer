package com.inn.loganalyzer.service;

import com.inn.loganalyzer.utils.LogRecord;

import java.util.List;

public interface LogAnalyzer {
  LogRecord getMostRecentLog(String logType, String filePath);

  LogRecord getLastError(String filePath);

  List<LogRecord> searchByErrorMessage(String message, String filePath);
}
