package com.inn.loganalyzer.controller;

import com.inn.loganalyzer.service.LogAnalyzer;
import com.inn.loganalyzer.utils.LogRecord;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(path = "/LogAnalyzer")
public class LogAnalyzerController {
  private final LogAnalyzer logAnalyzerService;

  public LogAnalyzerController(LogAnalyzer logAnalyzerService) {
    this.logAnalyzerService = logAnalyzerService;
  }

  @GetMapping("/mostRecent")
  public LogRecord getMostRecentLog(@RequestParam String logType, @RequestParam String filePath) {
    return logAnalyzerService.getMostRecentLog(logType, filePath);
  }

  @GetMapping("/lastError")
  public LogRecord getLastError(@RequestParam String filePath) {
    return logAnalyzerService.getLastError(filePath);
  }

  @GetMapping("/search")
  public List<LogRecord> searchByErrorMessage(@RequestParam String message, @RequestParam String filePath) {
    return logAnalyzerService.searchByErrorMessage(message, filePath);
  }
}
