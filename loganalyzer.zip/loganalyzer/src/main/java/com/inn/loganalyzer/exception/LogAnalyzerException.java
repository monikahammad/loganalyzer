package com.inn.loganalyzer.exception;

public class LogAnalyzerException extends RuntimeException {
  public LogAnalyzerException(String message) {
    super(message);
  }
}