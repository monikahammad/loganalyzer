package com.inn.loganalyzer.service.impl;

import com.inn.loganalyzer.exception.LogAnalyzerException;
import com.inn.loganalyzer.service.LogFileProcessor;
import com.inn.loganalyzer.utils.LogRecord;
import com.inn.loganalyzer.utils.LogRecord.LogType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Service;

import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class CSVLogFileProcessor implements LogFileProcessor {
  private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

  @Override
  public List<LogRecord> loadLogs(String filePath) {
    log.debug("Loading logs from CSV file: {}", filePath);
    List<LogRecord> logRecords = new ArrayList<>();
    try (FileReader reader = new FileReader(filePath);
        CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader())) {
      for (CSVRecord csvRecord : csvParser) {
        LogRecord logRecord = new LogRecord();
        logRecord.setLogType(LogType.valueOf(csvRecord.get("Log Type")));
        logRecord.setOccurredOn(LocalDateTime.parse(csvRecord.get("Timestamp/occured on"), formatter));
        logRecord.setDescription(csvRecord.get("message/description"));
        logRecords.add(logRecord);
      }
      log.debug("Loaded {} log records from CSV file: {}", logRecords.size(), filePath);
    } catch (IOException e) {
      log.error("Error occurred in loadLogs from CSV exception: ", e);
      throw new LogAnalyzerException("Please provide correct file path");
    }
    return logRecords;
  }
}
