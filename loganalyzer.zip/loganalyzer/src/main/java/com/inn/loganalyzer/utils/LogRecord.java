package com.inn.loganalyzer.utils;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
public class LogRecord {
  private LogType logType;
  private LocalDateTime occurredOn;
  private String description;

  public enum LogType {
    INFO, ERROR, WARNING
  }
}
