package com.inn.loganalyzer.service;

import com.inn.loganalyzer.utils.LogRecord;

import java.util.List;

public interface LogFileProcessor {
  List<LogRecord> loadLogs(String filePath);
}
