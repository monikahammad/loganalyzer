package com.inn.loganalyzer.service.impl;

import com.inn.loganalyzer.exception.LogAnalyzerException;
import com.inn.loganalyzer.service.LogFileProcessor;
import com.inn.loganalyzer.utils.LogRecord;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class ExcelLogFileProcessor implements LogFileProcessor {
  private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

  @Override
  public List<LogRecord> loadLogs(String filePath) {
    log.debug("Loading logs from Excel file: {}", filePath);
    List<LogRecord> logRecords = new ArrayList<>();
    try (InputStream is = Files.newInputStream(Path.of(filePath)); Workbook workbook = new XSSFWorkbook(is)) {
      Sheet sheet = workbook.getSheetAt(0);
      for (Row row : sheet) {
        if (row.getRowNum() == 0) {
          continue;
        }
        LogRecord logRecord = new LogRecord();
        logRecord.setLogType(LogRecord.LogType.valueOf(row.getCell(0).getStringCellValue()));
        logRecord.setOccurredOn(LocalDateTime.parse(row.getCell(1).getStringCellValue(), formatter));
        logRecord.setDescription(row.getCell(2).getStringCellValue());
        logRecords.add(logRecord);
      }
      log.debug("Loaded {} log records from CSV file: {}", logRecords.size(), filePath);
    } catch (IOException e) {
      log.error("Error occurred in loadLogs from Excel exception: ", e);
      throw new LogAnalyzerException("Please provide correct file path");
    }
    return logRecords;
  }
}

