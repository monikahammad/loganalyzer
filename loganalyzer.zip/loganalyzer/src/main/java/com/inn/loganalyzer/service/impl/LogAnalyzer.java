package com.inn.loganalyzer.service.impl;

import com.inn.loganalyzer.exception.LogAnalyzerException;
import com.inn.loganalyzer.utils.LogRecord;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
@Slf4j
public class LogAnalyzer implements com.inn.loganalyzer.service.LogAnalyzer {
  private final CSVLogFileProcessor csvProcessor;
  private final ExcelLogFileProcessor excelProcessor;

  @Autowired
  public LogAnalyzer(CSVLogFileProcessor csvProcessor, ExcelLogFileProcessor excelProcessor) {
    this.csvProcessor = csvProcessor;
    this.excelProcessor = excelProcessor;
  }

  private List<LogRecord> loadLogs(String filePath) {
    log.debug("Loading logs from file: {}", filePath);
    if (filePath.endsWith(".csv")) {
      return csvProcessor.loadLogs(filePath);
    } else if (filePath.endsWith(".xlsx")) {
      return excelProcessor.loadLogs(filePath);
    } else {
      throw new LogAnalyzerException("Unsupported file format: " + filePath);
    }
  }

  @Override
  public LogRecord getMostRecentLog(String logType, String filePath) {
    log.debug("Fetching most recent record for log type {} from file: {}", logType, filePath);
    LogRecord.LogType logTypeEnum = LogRecord.LogType.valueOf(logType);
    List<LogRecord> logRecords = loadLogs(filePath);
    return logRecords.stream().filter(log -> logTypeEnum.equals(log.getLogType()))
        .max(Comparator.comparing(LogRecord::getOccurredOn))
        .orElseThrow(() -> new LogAnalyzerException("No records found for log type: " + logType));
  }

  @Override
  public LogRecord getLastError(String filePath) {
    log.debug("Fetching last error from file: {}", filePath);
    List<LogRecord> logRecords = loadLogs(filePath);
    return logRecords.stream().filter(log -> LogRecord.LogType.ERROR.equals(log.getLogType()))
        .max(Comparator.comparing(LogRecord::getOccurredOn))
        .orElseThrow(() -> new LogAnalyzerException("No error logs found"));
  }

  @Override
  public List<LogRecord> searchByErrorMessage(String message, String filePath) {
    log.debug("Searching error messages containing '{}' in file: {}", message, filePath);
    List<LogRecord> logRecords = loadLogs(filePath);
    List<LogRecord> results = logRecords.stream().filter(log -> log.getDescription().contains(message)).toList();
    if (results.isEmpty()) {
      log.warn("No error messages found containing '{}' in file: {}", message, filePath);
      throw new LogAnalyzerException("No error messages found containing: " + message);
    }
    return results;
  }
}
